package c189;


class HashTable {
    //KL: The hash table node dictionary Array
    private HashTableNode<String, Person>[] nodes;

    @SuppressWarnings("unchecked")
    HashTable(int size) {
        nodes = new HashTableNode[size];
    }
    
    
     //KL: Gets the hash index for the hash table
    private Integer getIndex(String name) {
        Integer hash = name.hashCode() % nodes.length;

        if (hash < 0) {
            hash += nodes.length;
        }

        return hash;
    }
    
    //KL: Add the first and last name into a full name
    private static String namify(String first_name, String last_name) {
        return first_name + " " + last_name;
    }
    
     //KL: Add Information to Hash Table
    @SuppressWarnings("unchecked")
    Person addData(String first_name, String last_name, String email_address, String phone_number) {
        Person person = new Person(first_name, last_name, email_address, phone_number);
        int hash = getIndex(person.name);

        //KL: Check if the person was already added to hash table
        for (HashTableNode<String, Person> node = nodes[hash]; node != null; node = node.next) {
            if (hash == node.hashIndex && person.name.equals(node.name)) {
                Person previous = node.person;
                node.person = person;
                System.out.println(person.name + " was updated in the Hash Table");
                return previous;
            }
        }
        //KL: Add the person into the hash table
        HashTableNode<String, Person> node = new HashTableNode(hash, person.name, person, nodes[hash]);
        nodes[hash] = node;
        System.out.println(person.name + " was added into the Hash Table");
        return person;
    }
    
     //KL: Delete information
    Boolean deleteData(String first_name, String last_name) {
        String name = namify(first_name, last_name);
        int hash = getIndex(name);
        HashTableNode<String, Person> previous = null;

        //KL: Search the hash table for the person
        for (HashTableNode<String, Person> node = nodes[hash]; node != null; node = node.next) {
            if (hash == node.hashIndex && name.equals(node.name)) {
                if (previous != null) {
                    previous.next = node.next;
                } else {
                    nodes[hash] = node.next;
                }
                System.out.println(name + " was deleted from the Hash Table");
                return true;
            }
            previous = node;
        }
        System.out.println(name + " was not Found in the Hash Table. Please Check the Spelling and try again.");
        return false;
    } 
    
    //KL: LookUp Information by Search for a person by name
    Person lookUp(String first_name, String last_name) {
        String name = namify(first_name, last_name);
        int hash = getIndex(name);

        //KL: Search the hash table and its nodes
        for (HashTableNode<String, Person> node = nodes[hash]; node != null; node = node.next) {
            if (name.equals(node.name)) {
                System.out.println(name + " was found in the Hash Table with the email address: " + node.person.emailAddress + " and the phone number: " + node.person.phoneNumber);
                return node.person;
            }
        }
        System.out.println(name + " was not Found in the Hash Table. Please Check the Spelling and try again.");
        return null;
    }
}