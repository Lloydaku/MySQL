package c189;


class HashTableNode<string, Person> {

    final int hashIndex;
    final string name;
    Person person;
    
    
    //KL: linked-list setup
    HashTableNode<string, Person> next;

    HashTableNode(int hash, string name, Person person, HashTableNode<string, Person> next) {
        this.hashIndex = hash;
        this.name = name;
        this.person = person;
        this.next = next;
    }
}
