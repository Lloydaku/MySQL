/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c189;



/**
 *
 * @author Klinn
 */
public class Main {
    
    public static void main(String[] args) {
        
        //runBinaryTree();
        
        runHastTable();
    }
   
    
    //KL: Test Data for Binary Tree
    private static void runBinaryTree(){
        BinaryTree bTree = new BinaryTree();
        
        
        System.out.println("Adding Data to Binary Tree");
        bTree.addData("Bob", "Smith", "bsmith@somewhere.com", "555-235-1111");
        bTree.addData("Jane", "Williams", "jw@something.com", "555-235-1112");
        bTree.addData("Mohammed", "al-Salam", "mas@someplace.com", "555-235-1113");
        bTree.addData("Pat", "Jones", "pjones@homesweethome.com", "555-235-1114");
        bTree.addData("Billy", "Kidd", "billy_the_kid@nowhere.com", "555-235-1115");
        bTree.addData("H.", "Houdini", "houdini@noplace.com", "555-235-1116");
        bTree.addData("Jack", "Jones" , "jjones@hill.com" , "555-235-1117");
        bTree.addData("Jill", "Jones", "jillj@hill.com", "555-235-1118");
        bTree.addData("John", "Doe", "jdoe@somedomain.com", "555-235-1119");
        bTree.addData("Jane", "Doe", "jdoe@somedomain.com", "555-235-1120");
        System.out.println("");
        
        //KL: Looking up Information
        System.out.println("Looking up Information");
        bTree.lookUp("Pat", "Jones");
        bTree.lookUp("Billy", "Kidd");
        System.out.println("");
        
        //KL: Deleting
        System.out.println("Deleting Information");
        bTree.deleteData("John", "Doe");
        System.out.println("");

        System.out.println("Adding Data");
        bTree.addData("Test", "Case", "Test_Case@testcase.com", "555-235-1121");
        bTree.addData("Nadezhda", "Kanachekhovskaya", "dr.nadezhda.kanacheckovskaya@somehospital.moscow.ci.ru" , "555-235-1122");
        bTree.addData("Jo", "Wu", "wu@h.com", "555-235-1123");
        bTree.addData("Millard", "Fillmore", "millard@theactualwhitehouse.us", "555-235-1124");
        bTree.addData("Bob", "vanDyke", "vandyke@nodomain.com", "555-235-1125");
        bTree.addData("Upside", "Down", "upsidedown@rightsideup.com", "555-235-1126");
        System.out.println("");
        
        //KL: Lookup unfound data
        System.out.println("Looking up Inforamtion");
        bTree.lookUp("Jack", "Jones");
        bTree.lookUp("Nadezhda", "Kanachekhovskaya");
        System.out.println("");
        
        //KL: Deleting
        System.out.println("Deleting Information");
        bTree.deleteData("Jill", "Jones");
        bTree.deleteData("John", "Doe");
        System.out.println("");
        
        //KL: Looking up Information
        System.out.println("Looking up Information");
        bTree.lookUp("Jill", "Jones");
        bTree.lookUp("John", "Doe");
        
        System.out.println("");
    }
    
    // Test Hash Table
     private static void runHastTable(){
         HashTable hTable = new HashTable(13);
         
       System.out.println("Adding Data to Hash Table");
        hTable.addData("Bob", "Smith", "bsmith@somewhere.com", "555-235-1111");
        hTable.addData("Jane", "Williams", "jw@something.com", "555-235-1112");
        hTable.addData("Mohammed", "al-Salam", "mas@someplace.com", "555-235-1113");
        hTable.addData("Pat", "Jones", "pjones@homesweethome.com", "555-235-1114");
        hTable.addData("Billy", "Kidd", "billy_the_kid@nowhere.com", "555-235-1115");
        hTable.addData("H.", "Houdini", "houdini@noplace.com", "555-235-1116");
        hTable.addData("Jack", "Jones" , "jjones@hill.com" , "555-235-1117");
        hTable.addData("Jill", "Jones", "jillj@hill.com", "555-235-1118");
        hTable.addData("John", "Doe", "jdoe@somedomain.com", "555-235-1119");
        hTable.addData("Jane", "Doe", "jdoe@somedomain.com", "555-235-1120");
        System.out.println("");
        
        //KL: Looking up Information
        System.out.println("Looking up Information");
        hTable.lookUp("Pat", "Jones");
        hTable.lookUp("Billy", "Kidd");
        System.out.println("");
        
        //KL: Deleting
        System.out.println("Deleting Information");
        hTable.deleteData("John", "Doe");
        System.out.println("");

        System.out.println("Adding Data");
        hTable.addData("Test", "Case", "Test_Case@testcase.com", "555-235-1121");
        hTable.addData("Nadezhda", "Kanachekhovskaya", "dr.nadezhda.kanacheckovskaya@somehospital.moscow.ci.ru" , "555-235-1122");
        hTable.addData("Jo", "Wu", "wu@h.com", "555-235-1123");
        hTable.addData("Millard", "Fillmore", "millard@theactualwhitehouse.us", "555-235-1124");
        hTable.addData("Bob", "vanDyke", "vandyke@nodomain.com", "555-235-1125");
        hTable.addData("Upside", "Down", "upsidedown@rightsideup.com", "555-235-1126");
        System.out.println("");
        
        //KL: Lookup unfound data
        System.out.println("Looking up Inforamtion");
        hTable.lookUp("Jack", "Jones");
        hTable.lookUp("Nadezhda", "Kanachekhovskaya");
        System.out.println("");
        
        //KL: Deleting
        System.out.println("Deleting Information");
        hTable.deleteData("Jill", "Jones");
        hTable.deleteData("John", "Doe");
        System.out.println("");
        
        //KL: Looking up Information
        System.out.println("Looking up Information");
        hTable.lookUp("Jill", "Jones");
        hTable.lookUp("John", "Doe");
        
        System.out.println("");
    }
}

