
package c189;

/**
 *
 * @author Klinn
 */
public class Person {
    
    String name;
    String emailAddress;
    String phoneNumber;
    
    //Constructor
    Person(String firstName, String lastName, String email, String phoneNumber) {
        this.name = firstName + " " + lastName;
        this.emailAddress = email;
        this.phoneNumber = phoneNumber;
    }
    
}
