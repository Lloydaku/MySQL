
package c189;

/**
 *
 * @author Klinn
 */
class BinaryTreeNode {

    Person person;
    BinaryTreeNode rightChild;
    BinaryTreeNode leftChild;
    
    BinaryTreeNode() {
        person = null;
        rightChild = null;
        leftChild = null;
    }
    
    BinaryTreeNode(Person person) {
        this.person = person;
        rightChild = null;
        leftChild = null;
    }
    
    //KL: Add data to Binary Tree
    Person addData(String firstName, String lastName, String email, String phoneNumber) {
        Person person = new Person(firstName, lastName, email, phoneNumber);
        if (person.name.compareTo(this.person.name) == 0) {
            
            System.out.println(person.name + " was replaced in the Binary Tree with correct information.");
            return this.person;
        } else if (person.name.compareTo(this.person.name) < 0){
            if (leftChild == null) {
                leftChild = new BinaryTreeNode(person);
                System.out.println(person.name + " was inserted into the Binary Tree.");
                return leftChild.person;
            } else {
                return leftChild.addData(firstName, lastName, email, phoneNumber);
            }
        } else {
            if (rightChild == null) {
                rightChild = new BinaryTreeNode(person);
                
                System.out.println(person.name + " was inserted into the Binary Tree.");
                return rightChild.person;
            } else {
                return rightChild.addData(firstName, lastName, email, phoneNumber);
            }
        }
    }
    
    //KL: Delete data from Binary Tree
    Boolean delete(String name, BinaryTreeNode tempRoot) {
        if (name.compareTo(person.name) == 0) {
            if (leftChild != null && rightChild != null) {
                return rightChild.delete(name, this);
            } else if (tempRoot.leftChild == this) {
                tempRoot.leftChild = leftChild != null ? leftChild: rightChild;
                System.out.println(name + " was deleted from the binary tree");
                return true;
            } else if (tempRoot.rightChild == this) {
                tempRoot.rightChild = leftChild != null ? leftChild : rightChild;

                System.out.println(name + " was deleted from the binary tree");
                return true;
            }
        } else if (name.compareTo(person.name) < 0) {
            if (leftChild != null) {
                return leftChild.delete(name, this);
            } else {
                System.out.println(name + " was not Found in the Binary Tree. Please Check the Spelling and try again.");
                return false;
            }
        } else {
            if (rightChild != null) {
                return rightChild.delete(name, this);
            } else {
                System.out.println(name + " was not Found in the Binary Tree. Please Check the Spelling and try again.");
                return false;
            }
        }
        System.out.println(name + " was not deleted from the binary because they weren't in it");
        return false;
        
    }
    
    //Kl: lookUp information in Binary Tree
    Person lookUp(String name) {
         if (name.compareTo(person.name) == 0) {
            System.out.println(name + " was found in the binary tree with the email address " + person.emailAddress + " and the phone number " + person.phoneNumber);
            return person;
        } else if (name.compareTo(person.name) < 0) {
            if (leftChild == null) {
                System.out.println(name + " was not found in the binary tree");
                return null;
            } else {
                return leftChild.lookUp(name);
            }
        } else {
            if (rightChild == null) {
                System.out.println(name + " was not found in the binary tree");
                return null;
            } else {
                return rightChild.lookUp(name);
            }
        }
    }
}
