
package c189;

/**
 *
 * @author Klinn
 */
public class BinaryTree {
    
    //KL: Created Root of Tree
    private BinaryTreeNode root;
    
    //Constructor
    BinaryTree() {
        root = null;
    }
    //KL: Add the first and last name into a full name
    private static String fullName(String firstName, String lastName) {
        return firstName + " " + lastName;
    }
    //KL: Add Information to the Binary Tree
    Person addData(String firstName, String lastName, String email, String phoneNumber) {
        Person person = new Person(firstName, lastName, email, phoneNumber);
        //KL: Check if root is null
        if (root == null) {
            root = new BinaryTreeNode(person);
            System.out.println(person.name + " was added into the Binary Tree");
            return root.person;
        } else {
            return root.addData(firstName, lastName, email,phoneNumber);
        }
    }
    //KL: LookUp Method.  Search for First and Last Name
    Person lookUp(String firstName, String lastName) {
        String name = fullName(firstName, lastName);
        //KL: Check if root is null
        if (root == null) {
            System.out.println(name + " was not found in the Binary Tree. Please check the spelling and try again");
            return null;
        } else {
            return root.lookUp(name);
        }
    }
    
    //KL" DeleteData Method.
    Boolean deleteData(String firstName, String lastName) {
        String name = fullName(firstName, lastName);
        //KL: Check if root is null
        if (root == null) {
            System.out.println(name + " was not deleted from the Binary Tree. Data was not found. Pease check the spelling and try agian ");
            return false;
        } else {
            if (root.person.name.compareTo(name) == 0) {
                BinaryTreeNode tempRoot = new BinaryTreeNode();
                
                tempRoot.leftChild = root;
                root.delete(name, tempRoot);
                root = tempRoot.leftChild;
                
                System.out.println(name + " was successfully delete from the Binary Tree");
                return true;
            } else {
                return root.delete(name, null);
            }
        }
    }
    
}
