
/**
 *
 * @author Klinn
 */
public class BinaryTree {
    Node root;
    
    public void addNode (String firstName, String lastName, String email, String phoneNumber) {
        Node newNode = new Node (firstName, lastName, email, phoneNumber);
        
        if (root == null) {
          
            
    }
}






class Node {
    String name;
    String email;
    String phoneNumber;
    
    Node rightChild;
    Node leftChild;
    
    Node (String firstName, String lastName, String email, String phoneNumber) {
        this.name = firstName + lastName;
        this.email = email;
        this.phoneNumber = phoneNumber;
    }
    
    public String toString() {
        return "Name " + name + "Email " + email + "phone " + phoneNumber;
    }
}

}
